package com.project.utilities;

public class Utilities {
   
	//path
	public static final String pathofchrome="";
	public static final int a=29;
	
	//locators 
	public static final String Username="/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input";
	public static final String password="//html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/input";
	public static final String signin="/html/body/div[2]/div/div/div/div/div[2]/div/form/div[3]/button";
	public static final String screenshotpath="D:\\report";
}
