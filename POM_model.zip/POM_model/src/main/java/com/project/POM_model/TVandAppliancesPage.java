package com.project.POM_model;

import org.openqa.selenium.WebDriver;

import com.project.baseclass.BaseClass;
import com.relevantcodes.extentreports.ExtentTest;

public class TVandAppliancesPage extends BaseClass {

	public TVandAppliancesPage(WebDriver driver,ExtentTest test) {
		super(driver,test);
		// TODO Auto-generated constructor stub
	}

	
	
}
